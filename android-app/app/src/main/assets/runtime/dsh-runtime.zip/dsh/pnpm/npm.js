"use strict";
const argv = process.argv.slice(2);
let semver = null;
try { semver = require("semver"); } catch (_error) { semver = null; }

function fail(message, code) {
  process.stderr.write(`npm-shim: ${message}\n`);
  process.exit(code === undefined ? 1 : code);
}

function splitSpec(spec) {
  if (typeof spec !== "string" || spec.length === 0) fail("missing package spec");
  if (spec.startsWith("@")) {
    const slash = spec.indexOf("/");
    if (slash < 0) fail(`invalid scoped spec ${spec}`);
    const rest = spec.slice(slash + 1);
    const at = rest.indexOf("@");
    return at < 0 ? { name: spec, range: null } : { name: spec.slice(0, slash + 1 + at), range: rest.slice(at + 1) };
  }
  const at = spec.indexOf("@", 1);
  return at < 0 ? { name: spec, range: null } : { name: spec.slice(0, at), range: spec.slice(at + 1) };
}

function minimalParse(version) {
  const core = version.split("-")[0].split("+")[0];
  const parts = core.split(".");
  if (parts.length !== 3) return null;
  const nums = parts.map((part) => (/^\d+$/.test(part) ? Number(part) : null));
  if (nums.some((num) => num === null)) return null;
  return { major: nums[0], minor: nums[1], patch: nums[2], prerelease: version.includes("-") ? version.split("-").slice(1).join("-") : null };
}

function minimalCompare(a, b) {
  const pa = minimalParse(a);
  const pb = minimalParse(b);
  if (pa === null || pb === null) return 0;
  for (const key of ["major", "minor", "patch"]) {
    if (pa[key] !== pb[key]) return pa[key] < pb[key] ? -1 : 1;
  }
  if (pa.prerelease === pb.prerelease) return 0;
  if (pa.prerelease === null) return 1;
  if (pb.prerelease === null) return -1;
  return pa.prerelease < pb.prerelease ? -1 : 1;
}

function maxSatisfying(versions, range) {
  if (semver !== null && typeof semver.maxSatisfying === "function") {
    return semver.maxSatisfying(versions, range, { includePrerelease: false });
  }
  const text = String(range).trim();
  if (text === "" || text === "*" || text === "x") {
    const stable = versions.filter((entry) => minimalParse(entry) !== null && minimalParse(entry).prerelease === null);
    const pool = stable.length > 0 ? stable : versions;
    return pool.slice().sort(minimalCompare).at(-1) ?? null;
  }
  const parts = text.split(/\s+/).filter((part) => part.length > 0);
  const bounds = [];
  for (const part of parts) {
    if (part === "||") break;
    const operator = ["^", "~", ">=", ">", "<=", "<", "="].find((prefix) => part.startsWith(prefix));
    if (operator === undefined) {
      if (/^\d+\.\d+\.\d+(-[\w.]+)?$/.test(part)) bounds.push({ op: "=", version: part });
      else if (/^\d+$/.test(part)) bounds.push({ op: "^", version: `${part}.0.0` });
      else if (/^\d+\.\d+$/.test(part)) bounds.push({ op: "^", version: `${part}.0` });
      else if (part.includes("*") || part.includes("x")) bounds.push({ op: "*", version: "0.0.0" });
      else return null;
      continue;
    }
    bounds.push({ op: operator === "=" ? "=" : operator, version: part.slice(operator.length) });
  }
  const candidates = versions.filter((entry) => {
    const parsed = minimalParse(entry);
    if (parsed === null) return false;
    if (parsed.prerelease !== null) return false;
    return bounds.every((bound) => {
      const order = minimalCompare(entry, bound.version);
      switch (bound.op) {
        case "=": return order === 0;
        case ">=": return order >= 0;
        case ">": return order > 0;
        case "<=": return order <= 0;
        case "<": return order < 0;
        case "^": {
          const base = minimalParse(bound.version);
          return order >= 0 && parsed.major === base.major;
        }
        case "~": {
          const base = minimalParse(bound.version);
          return order >= 0 && parsed.major === base.major && parsed.minor === base.minor;
        }
        default: return true;
      }
    });
  });
  return candidates.length > 0 ? candidates.slice().sort(minimalCompare).at(-1) : null;
}

async function fetchJson(target) {
  const response = await fetch(target, {
    headers: { "accept": "application/json", "accept-encoding": "identity", "user-agent": "npm-shim/10.34.9 node/" + process.version },
  });
  if (!response.ok) fail(`registry answered ${response.status} for ${target}`);
  return await response.json();
}

async function main() {
  const positional = [];
  let json = false;
  let registry = null;
  for (const argument of argv) {
    if (argument === "--json") json = true;
    else if (argument.startsWith("--registry=")) registry = argument.slice("--registry=".length);
    else if (argument.startsWith("--")) continue;
    else positional.push(argument);
  }
  const command = positional.shift();
  if (command === undefined || command === "--version" || command === "-v" || command === "version") {
    process.stdout.write("10.34.9\n");
    return;
  }
  if (command !== "view" && command !== "info" && command !== "show") {
    fail(`unsupported command ${JSON.stringify(command)}; only 'view' is provided by the device npm shim`);
  }
  const spec = positional.shift();
  if (spec === undefined) fail("view needs a package spec");
  const fields = positional;
  const { name, range } = splitSpec(spec);
  const base = (registry === null || registry === "" ? "https://registry.npmjs.org" : registry).replace(/\/+$/, "");
  const encoded = encodeURIComponent(name);
  const doc = await fetchJson(`${base}/${encoded}`);
  if (doc === null || typeof doc !== "object" || doc.versions === undefined) fail(`${name} not found in registry`);
  let matched;
  if (range === null) {
    const latest = doc["dist-tags"] !== undefined && doc["dist-tags"].latest !== undefined ? doc["dist-tags"].latest : null;
    matched = latest !== null && doc.versions[latest] !== undefined ? [doc.versions[latest]] : [doc];
  } else if (doc["dist-tags"] !== undefined && Object.hasOwn(doc["dist-tags"], range)) {
    const tagged = doc["dist-tags"][range];
    matched = doc.versions[tagged] !== undefined ? [doc.versions[tagged]] : [];
  } else if (doc.versions[range] !== undefined) {
    matched = [doc.versions[range]];
  } else {
    const best = maxSatisfying(Object.keys(doc.versions), range);
    matched = best !== null && doc.versions[best] !== undefined ? [doc.versions[best]] : [];
  }
  if (matched.length === 0) fail(`no version of ${name} matches ${range}`);
  const render = (manifest) => {
    if (fields.length === 0) {
      const { readme, _id, _nodeVersion, _npmVersion, _npmUser, ...rest } = manifest;
      return rest;
    }
    const picked = {};
    for (const field of fields) {
      if (field === "versions") picked[field] = Object.keys(doc.versions);
      else if (field === "time") picked[field] = doc.time;
      else if (field === "dist-tags") picked[field] = doc["dist-tags"];
      else if (Object.hasOwn(manifest, field)) picked[field] = manifest[field];
    }
    return picked;
  };
  const output = matched.length === 1 ? render(matched[0]) : matched.map(render);
  process.stdout.write(`${JSON.stringify(output)}\n`);
}

main().catch((error) => fail(String(error && error.message ? error.message : error)));
